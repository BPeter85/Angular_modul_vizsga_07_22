import { Component } from '@angular/core';

@Component({
  selector: 'app-feladat',
  templateUrl: './feladat.component.html',
  styleUrls: ['./feladat.component.css']
})
export class FeladatComponent {
  szam: number = 1;
  kiiro:string = "";
  eredmenyek: string[] = [];

  EredmenyMentes(): void {
    let oszto: number = 0;
    for (let i:number = 0; i <= this.szam; i++) {
      if (this.szam % i == 0) {
        oszto++;
      }
    }
    if (oszto == 2) {
      this.kiiro = `A(z) ${this.szam}: prím`;
      this.eredmenyek.push(`Az ${this.szam} prím`);
    }
    else {
      this.kiiro = `A(z) ${this.szam}: NEM prím`;
      this.eredmenyek.push(`Az ${this.szam} NEM prím`);
    }
  }


}